#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "account.h"
#include "bool.h"
#ifndef LIST_H
struct list;
#define LIST_H
#define MIN_LIST_SIZE 10
#define DOUBLE(X) ((X)*(X))
#endif
