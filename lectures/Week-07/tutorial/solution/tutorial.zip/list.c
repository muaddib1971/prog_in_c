#include "list.h"
BOOLEAN list_init(struct list * list)
{
        return FALSE;
}

BOOLEAN list_add(struct list * list, struct account account)
{
        return FALSE;
}

BOOLEAN list_del(struct list * list, char accno[])
{
        return FALSE;
}

void list_free(struct list * list)
{
}
