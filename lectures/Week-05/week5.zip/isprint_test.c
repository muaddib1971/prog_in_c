#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(void)
{
    int ch;
    while(isprint(ch=getchar()) && ch != EOF)
        putchar(ch);
    putchar('\n');
    return EXIT_SUCCESS;
}
