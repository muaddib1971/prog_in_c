#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    int * p;
    printf("%d\n", *p);
    return EXIT_SUCCESS;
}
