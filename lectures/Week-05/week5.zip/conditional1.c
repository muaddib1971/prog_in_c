#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int * p;
    /* remove the #if below to properly initialise p */
#if 0
    int i=42;
    p=&i;
#endif
#ifdef DEBUG
    fprintf(stderr, "the value of p is %p\n", (void*)p);
#endif
    printf("value pointed to by p is %d\n", *p);
    return EXIT_SUCCESS;
}
