#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    char name[1];
    strcpy(name, "hi fred, how are things?");
    printf("%s\n", name);
    return EXIT_SUCCESS;
}
