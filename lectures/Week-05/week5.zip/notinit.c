#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    char line[80];
    if(strcmp(line,"hello")==0)
    {
        printf("the greeting has been set correctly.\n\n");
    }
    return EXIT_SUCCESS;
}
