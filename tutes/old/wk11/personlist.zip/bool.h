#ifndef BOOL_H
#define BOOL_H
typedef enum {FALSE, TRUE} BOOLEAN;
#endif
